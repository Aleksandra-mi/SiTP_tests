﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace final_project1
{
    public partial class MainWindow : Window
    {
        static User[] U;
        static Feedback[] F;
        static Hash_user H;
        static Tree_login TL;
        static Tree_name TN;
        static List<Feedback> S;
        static string S1 = "1.txt";
        static string S2 = "2.txt";
        static int Hash_size = 50;
        public MainWindow()
        {
            InitializeComponent();
            U = ReadF_user(S1);
            if (U != null)
            {
                Users_gr.ItemsSource = U;
                H = new Hash_user(U, Hash_size);
                if (!(U.Length>Hash_size))
                {
                    H = new Hash_user(U, Hash_size);
                }
                else
                    MessageBox.Show("Размер таблицы меньше количества данных в файле", "Ошибка чтения", MessageBoxButton.OK);
            }
            else
            {
                U = new User[0];
                H = new Hash_user(Hash_size);
            }

            F = ReadF_feed(S2);
            if (F != null)
            {
                Feed_gr.ItemsSource = F;
                TL = new Tree_login(F);
                TN = new Tree_name(F);
            }
            else
            {
                F = new Feedback[0];
                TL = new Tree_login();
                TN = new Tree_name();
            }
            
        }
        //чтение из файлов
        static User[] ReadF_user(string s)
        {
            using (StreamReader b = new StreamReader(s, System.Text.Encoding.UTF8))
            {
                StreamReader a = new StreamReader(s, System.Text.Encoding.UTF8);
                if (a.ReadToEnd() != "")
                {
                    int n = int.Parse(b.ReadLine());
                    User[] use = new User[n];
                    int i = 0;
                    while (i < n)
                    {
                        string str = b.ReadLine();
                        string[] ss = str.Split('/');
                        double dd = Convert.ToDouble(ss[2]);
                        use[i] = new User(ss[0], ss[1], dd);
                        i++;
                    }
                    return use;
                }
                else
                    return null;
            }
        }
        static Feedback[] ReadF_feed(string s)
        {
            using (StreamReader a = new StreamReader(s, System.Text.Encoding.UTF8))
            {
                if (a.ReadToEnd() != "")
                {
                    StreamReader b = new StreamReader(s, System.Text.Encoding.UTF8);
                    int n = int.Parse(b.ReadLine());
                    Feedback[] f = new Feedback[n];
                    int i = 0;
                    while (i < n)
                    {
                        string str = b.ReadLine();
                        string[] sss = str.Split('/');
                        f[i] = new Feedback(sss[0], sss[1], sss[2]);
                        i++;
                    }
                    return f;
                }
                else
                    return null;
            }
        }
        //выбор файлов
        private void Users_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog u = new Microsoft.Win32.OpenFileDialog();
            //u.InitialDirectory = @"D:\";
            u.DefaultExt = ".txt";
            u.Filter = "Text documents (.txt)|*.txt";
            Nullable<bool> result = u.ShowDialog();

            if (result == true)
            {
                S1 = u.FileName;
                U = ReadF_user(S1);
                if (U != null)
                {
                    Users_gr.ItemsSource = U;
                    H = new Hash_user(U, Hash_size);
                }
                else
                {
                    U = new User[0];
                    Users_gr.ItemsSource = null;
                    H = new Hash_user(Hash_size);
                }
            }
            //else
            //{
            //    S1 = u.FileName;
            //}
        }
        private void Feed_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog u = new Microsoft.Win32.OpenFileDialog();
            //u.InitialDirectory = @"D:\";
            u.DefaultExt = ".txt";
            u.Filter = "Text documents (.txt)|*.txt";
            Nullable<bool> result = u.ShowDialog();

            if (result == true)
            {
                S2 = u.FileName;
                F = ReadF_feed(S2);
                if (F != null)
                {
                    Feed_gr.ItemsSource = F;
                    TL = new Tree_login(F);
                    TN = new Tree_name(F);
                }
                else
                {
                    Feed_gr.ItemsSource = null;
                    TL = new Tree_login();
                    TN = new Tree_name();
                    F = new Feedback[0];
                }
            }
        }
        //запись в файлы
        static void AddF_user(User u)
        {
            using (StreamWriter a = new StreamWriter(S1, false))
            {
                if (U != null)
                {
                    User[] uu = new User[U.Length + 1];
                    for (int i = 0; i < U.Length; i++)
                    {
                        uu[i] = U[i];
                    }
                    uu[U.Length] = u;
                    U = uu;
                    a.WriteLine(U.Length);
                    for (int j = 0; j < U.Length; j++)
                        a.WriteLine(U[j].login + "/" + U[j].data + "/" + U[j].rate.ToString());
                }
                else
                {
                    U[0] = u;
                    a.WriteLine("1");
                    a.WriteLine(U[0].login + "/" + U[0].data + "/" + U[0].rate.ToString());
                }

            }
        }
        static void AddF_feed(Feedback f)
        {
            using (StreamWriter a = new StreamWriter(S2, false))
            {
                if (F != null)
                {
                    Feedback[] ff = new Feedback[F.Length + 1];
                    for (int i = 0; i < F.Length; i++)
                    {
                        ff[i] = F[i];
                    }
                    ff[F.Length] = f;
                    F = ff;
                    a.WriteLine(F.Length);
                    for (int j = 0; j < F.Length; j++)
                        a.WriteLine(F[j].login + "/" + F[j].name + "/" + F[j].feed);
                }
                else
                {
                    F[0] = f;
                    a.WriteLine("1");
                    a.WriteLine(F[0].login + "/" + F[0].name + "/" + F[0].feed);
                }
                
            }
        }
        //удаление из файлов
        static void DelF_user(User u)
        {
            using (StreamWriter a = new StreamWriter(S1, false))
            {
                int i = 0;
                User[] uu = new User[U.Length - 1];
                while (U[i].login != u.login)
                {
                    uu[i] = U[i];
                    i++;
                }
                for (int j = i; j < U.Length-1; j++)
                {
                    uu[j] = U[j + 1];
                }
                U = uu;
                a.WriteLine(U.Length);
                for (int k = 0; k < U.Length; k++)
                {
                    a.WriteLine(U[k].login + "/" + U[k].data + "/" + U[k].rate);
                }
            }
        }
        static void DelF_feed(Feedback f)
        {
            using (StreamWriter a = new StreamWriter(S2, false))
            {
                int i = 0;
                Feedback[] ff = new Feedback[F.Length - 1];
                while (F[i] != f)
                {
                    ff[i] = F[i];
                    i++;
                }
                for (int j = i; j < F.Length - 1; j++)
                {
                    ff[j] = F[j + 1];
                }
                F = ff;
                a.WriteLine(F.Length);
                for (int k = 0; k < F.Length; k++)
                {
                    a.WriteLine(F[k].login + "/" + F[k].name + "/" + F[k].feed);
                }
            }
        }
        //пользователи(добавление)
        private void Users_add_click(object sender, RoutedEventArgs e)
        {
            string l = u4.Text;
            string d = u5.Text;
            string r = u6.Text;
            bool f1 = C1(l);
            bool f2 = C2(d);
            bool f3 = C3(r);
            if (f1 && f2 && f3)
            {
                if (U != null)
                {
                    if (U.Length < H.n)
                    {
                        User u = new User(l, d, Convert.ToDouble(r));
                        if (!((H.Search(u) == -1) || (H.Search(u) == -2)))
                        {
                            MessageBox.Show("Запись с данным логином уже есть", "Ошибка добавления", MessageBoxButton.OK);
                        }
                        else if ((H.Search(u) == -1) || (H.Search(u) == -2))
                        {
                            H.Add(u);
                            AddF_user(u);
                            Users_gr.ItemsSource = null;
                            Users_gr.ItemsSource = U;
                        }
                        else if (H.Search(u) == -3)
                            MessageBox.Show("Таблица заполнена", "Ошибка добавления", MessageBoxButton.OK);
                    }
                    else
                        MessageBox.Show("Таблица заполнена", "Ошибка добавления", MessageBoxButton.OK);
                }
                else
                {
                    User u = new User(l, d, Convert.ToDouble(r));
                    H.Add(u);
                    AddF_user(u);
                    Users_gr.ItemsSource = null;
                    Users_gr.ItemsSource = U;
                }
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            u4.Text = "";
            u5.Text = "";
            u6.Text = "";
        }
        //пользователи(удаление)
        private void Users_del_click(object sender, RoutedEventArgs e)
        {
            string l = u4.Text;
            bool f1 = C1(l);
            if (f1)
            {
                User u = new User(l);
                if (!((H.Search(u) == -1) || (H.Search(u) == -2) || (H.Search(u) == -3)))
                {
                    H.Del(u);
                    DelF_user(u);
                    Users_gr.ItemsSource = null;
                    Users_gr.ItemsSource = U;
                    bool f = true;
                    //TL.tree.Del_All(l, ref TL.tree.head, ref f);
                    List < Feedback > a = new List<Feedback>();
                    TL.tree.Search(l, TL.tree.head, ref a);
                    if (a != null)
                    {
                        MessageBox.Show("Отзывы пользователя были удалены", "Успешное удаление", MessageBoxButton.OK);
                    }
                    for (int i = 0; i < a.Count; i++)
                    {
                        f = true;
                        //TL.tree.Delete(a[i], ref TL.tree.head, ref f);
                        //TN.tree.Delete(a[i], ref TN.tree.head, ref f);
                        DelF_feed(a[i]);
                        TL = new Tree_login(F);
                        TN = new Tree_name(F);
                        Feed_gr.ItemsSource = null;
                        Feed_gr.ItemsSource = F;
                    }
                }
                else if ((H.Search(u) == -1 ) || (H.Search(u) == -3))
                {
                    MessageBox.Show("Запись с данным логином отсутствует", "Ошибка удаления", MessageBoxButton.OK);
                }
                else if (H.Search(u) == -2)
                    MessageBox.Show("Таблица пустая", "Ошибка удаления", MessageBoxButton.OK);
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            u4.Text = "";
            u5.Text = "";
            u6.Text = "";
        }
        //пользователи(поиск)
        private void Users_search_click(object sender, RoutedEventArgs e)
        {
            string l = u4.Text;
            bool f1 = C1(l);
            if (f1)
            {
                User u = new User(l);
                if (!((H.Search(u) == -1) || (H.Search(u) == -2) || (H.Search(u) == -3)))
                {
                    int SS = H.Search(u);
                    u.data = H.hashtable[SS].user.data;
                    u.rate = H.hashtable[SS].user.rate;
                    MessageBox.Show($"{u.login} {u.data} {u.rate}", "Успешный поиск", MessageBoxButton.OK);
                }
                else if ((H.Search(u) == -1) || (H.Search(u) == -3))
                {
                    MessageBox.Show("Запись с данным логином отсутствует", "Ошибка поиска", MessageBoxButton.OK);
                }
                else if (H.Search(u) == -2)
                    MessageBox.Show("Таблица пустая", "Ошибка поиска", MessageBoxButton.OK);
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            u4.Text = "";
            u5.Text = "";
            u6.Text = "";
        }
        //пользователи(отображение)
        private void Users_show_click(object sender, RoutedEventArgs e)
        {
            Hash Hash = new Hash(H);
            Hash.Show();
            Hash.Visibility = Visibility.Visible;
        }
        //отзывы(добавление)
        private void Feed_add_click(object sender, RoutedEventArgs e)
        {
            string l = f4.Text;
            string n = f5.Text;
            string f = f6.Text;
            bool f1 = C1(l);
            bool f2 = C4(n);
            bool f3 = C5(f);
            if (f1 && f2 && f3)
            {
                User u = new User(l);
                if (!((H.Search(u) == -1) || (H.Search(u) == -2) || (H.Search(u) == -3)))
                {
                    Feedback ff = new Feedback(l, n, f);
                    if (!(TL.tree.S(ff, TL.tree.head) == true))
                    {
                        bool b = true;
                        //TL.tree.Add(ff, ref TL.tree.head, ref b);
                        //TN.tree.Add(ff, ref TN.tree.head, ref b);
                        AddF_feed(ff);
                        TL = new Tree_login(F);
                        TN = new Tree_name(F);
                        Feed_gr.ItemsSource = null;
                        Feed_gr.ItemsSource = F;
                    }
                    else
                        MessageBox.Show("Такая запись уже есть", "Ошибка добавления", MessageBoxButton.OK);
                }
                else
                    MessageBox.Show("Пользователя с таким логином не существует", "Ошибка добавления", MessageBoxButton.OK);
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            f4.Text = "";
            f5.Text = "";
            f6.Text = "";
        }
        //отзывы(удаление)
        private void Feed_del_click(object sender, RoutedEventArgs e)
        {
            string l = f4.Text;
            string n = f5.Text;
            string f = f6.Text;
            bool f1 = C1(l);
            bool f2 = C4(n);
            bool f3 = C5(f);
            if (f1 && f2 && f3)
            {
                Feedback ff = new Feedback(l, n, f);
                if (TL.tree.S(ff, TL.tree.head) == true)
                {
                    bool b = true;
                    //TL.tree.Delete(ff, ref TL.tree.head, ref b);
                    //TN.tree.Delete(ff, ref TN.tree.head, ref b);
                    DelF_feed(ff);
                    TL = new Tree_login(F);
                    TN = new Tree_name(F);
                    Feed_gr.ItemsSource = null;
                    Feed_gr.ItemsSource = F;
                }
                else
                    MessageBox.Show("Такой записи нет", "Ошибка удаления", MessageBoxButton.OK);
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            f4.Text = "";
            f5.Text = "";
            f6.Text = "";
        }
        //отзывы(поиск)
        private void Feed_search_click(object sender, RoutedEventArgs e)
        {
            string l = f4.Text;
            bool f1 = C1(l);
            if (f1)
            {
                List<Feedback> a = new List<Feedback>();
                TL.tree.head.Search(l, TL.tree.head, ref a);
                if (a!= null)
                {
                    string ss = "";
                    for (int i = 0; i < a.Count; i++)
                    {
                        ss += $" {a[i].login} {a[i].name} {a[i].feed}";
                        ss += "\n";
                    }
                    MessageBox.Show(ss, "Успешный поиск", MessageBoxButton.OK);
                }
                else
                    MessageBox.Show("Отзывы с данным логином отсутствуют", "Ошибка поиска", MessageBoxButton.OK);
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            f4.Text = "";
            f5.Text = "";
            f6.Text = "";
        }
        //отзывы(отображение)
        private void Feed_show_click(object sender, RoutedEventArgs e)
        {
            Trees Tree1 = new Trees(TL);
            Tree1.Show();
            Tree1.Visibility = Visibility.Visible;
        }
        //отчет(поиск)
        private void SS_search_click(object sender, RoutedEventArgs e)
        {
            string n = s2.Text;
            string r1 = s4.Text;
            string r2 = s6.Text;
            bool f1 = C4(n);
            bool f2 = C3(r1);
            bool f3 = C3(r2);
            if (f1 && f2 && f3)
            {
                List<Feedback> a = new List<Feedback>();
                TN.tree.head.Search(n, TN.tree.head, ref a);
                if (a != null)
                {
                    double R1 = Convert.ToDouble(r1);
                    double R2 = Convert.ToDouble(r2);
                    S = new List<Feedback>();
                    S = H.SS(a, R1, R2);
                    if (S.Count > 0)
                    {
                        SS_gr.ItemsSource = null;
                        SS_gr.ItemsSource = S;
                    }
                    else
                        MessageBox.Show("Пользователи с рейтингом в данном диапазоне не найдены", "Ошибка поиска", MessageBoxButton.OK);
                }
                else
                    MessageBox.Show("Отзывы с данным названием отсутствуют", "Ошибка поиска", MessageBoxButton.OK);
            }
            else
                MessageBox.Show("Перейдите в окно СПРАВКА для подробной информации", "Неверный формат данных", MessageBoxButton.OK);
            s2.Text = "";
            s4.Text = "";
            s6.Text = "";
        }
        //отчет(отображение)
        private void SS_show_click(object sender, RoutedEventArgs e)
        {
            Trees Tree2 = new Trees(TN);
            Tree2.Show();
            Tree2.Visibility = Visibility.Visible;
        }
        //СПРАВКА(отображение)
        private void Notes_click(object sender, RoutedEventArgs e)
        {
            Notes n = new Notes();
            n.Show();
            n.Visibility = Visibility.Visible;
        }
        //проверка поля(логин)
        bool C1(string s)
        {
            if (s != "" && s[0] != ' ')
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if (!((s[i] >= 'a' && s[i] <= 'z') /*|| (s[i] >= 'A' && s[i] <= 'Z')*/ || char.IsDigit(s[i]) || s[i] == '.' || s[i] == '_'))
                        return false;
                }
                return true;
            }
            else
                return false;
        }
        //проверка поля(дата)
        bool C2(string s)
        {
            if (s != "" && s[0] != ' ' && s.Length == 10)
            {
                for (int i = 0; i < 2; i++)
                {
                    if (!(char.IsDigit(s[i])))
                        return false;
                }
                if (!(s[2] == '.'))
                    return false;
                for (int i = 3; i < 5; i++)
                {
                    if (!(char.IsDigit(s[i])))
                        return false;
                }
                if (!(s[5] == '.'))
                    return false;
                for (int i = 6; i < 10; i++)
                {
                    if (!(char.IsDigit(s[i])))
                        return false;
                }
                return true;
            }
            else
                return false;
        }
        //проверка поля(рейтинг)
        bool C3(string s)
        {
            if ((s != "") && (s.Length >= 3))
            {
                if (!(s[0] >= '0' && s[0] <= '5'))
                    return false;
                if (!(s[1] == ','))
                    return false;
                for (int i = 2; i < s.Length; i++)
                {

                    if (!(s[i] >= '0' && s[i] <= '9'))
                        return false;
                }
                return true;
            }
            else if ((s != "") && (s.Length == 1))
            {
                if (!(s[0] >= '0' && s[0] <= '5'))
                    return false;
                else 
                    return true;
            }
            else
                return false;
        }
        //проверка поля(название)
        bool C4(string s)
        {
            if (s != "" && s[0] != ' ')
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if (!((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z') || (s[i] >= 'а' && s[i] <= 'я') || (s[i] >= 'А' && s[i] <= 'Я') || char.IsDigit(s[i]) || s[i] == '.' || s[i] == '_' || s[i] == '-' || s[i] == '!' || s[i] == '?' || s[i] == '*' || s[i] == ' '))
                        return false;
                }
                return true;
            }
            else
                return false;
        }
        //проверка поля(отзыв)
        bool C5(string s)
        {
            if (s != "" && s[0] != ' ')
                return true;
            else
                return false;
        }
    }
}
