﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_project1
{
    public class Tree_login
    {
        public t1 tree;
        public Tree_login()
        {
            tree = new t1();
        }
        public Tree_login(Feedback[] F)
        {
            bool f = true;
            tree = new t1();
            t1 a = tree.head;
            for (int i = 0; i < F.Length; i++)
            {
                tree.Add(F[i], ref a, ref f);
            }
            tree.head = a;
        }
    }
    public class t1
    {
        public List<Feedback> feed = new List<Feedback>();
        public t1 left;
        public t1 right;
        public t1 head = null;
        public int bal; // баланс -1(L>R) 0(L=R) 1(L<R)

        public t1()
        {
            bal = 0;
            left = null;
            right = null;
        }
        public void Add(Feedback F, ref t1 start, ref bool f)
        {
            if (start == null)
            {
                t1 t = new t1();
                t.feed.Add(F);
                start = t;
                f = true;
                //head = t;
            }
            
            else
            {
                if (String.Compare(F.login, start.feed[0].login) < 0) //левая строка меньше
                {
                    Add(F, ref start.left, ref f);
                    if (f == true)
                    {
                        if (start.bal == 1)
                        {
                            start.bal = 0;
                            f = false;
                        }
                        else if (start.bal == 0)
                        {
                            start.bal = -1;
                        }
                        else if (start.bal == -1)
                        {
                            t1 a = start.left;
                            //if (a != null)
                            //{
                            if (a.bal == -1)
                            {
                                start.left = a.right;
                                a.right = start;
                                start.bal = 0;
                                start = a;
                            }
                            else
                            {
                                t1 b = a.right;
                                if (b != null)
                                {
                                    a.right = b.left;
                                    b.left = a;
                                    start.left = b.right;
                                    b.right = start;
                                    if (b.bal == -1)
                                        start.bal = 1;
                                    else
                                        start.bal = 0;
                                    if (b.bal == 1)
                                        a.bal = -1;
                                    else
                                        a.bal = 0;
                                    start = b;
                                }

                            }
                            start.bal = 0;
                            f = false;
                            //}
                        }
                    }
                }
                else if (String.Compare(F.login, start.feed[0].login) > 0) //левая строка больше
                {
                    Add(F, ref start.right, ref f);
                    if (f == true)
                    {
                        if (start.bal == -1)
                        {
                            start.bal = 0;
                            f = false;
                        }
                        else if (start.bal == 0)
                        {
                            start.bal = 1;
                        }
                        else if (start.bal == 1)
                        {
                            t1 a = start.right;
                            //if (a != null)
                            //{
                            if (a.bal == 1)
                            {
                                start.right = a.left;
                                a.left = start;
                                start.bal = 0;
                                start = a;
                            }
                            else
                            {
                                t1 b = a.left;
                                if (b!=null)
                                {
                                    a.left = b.right;
                                    b.right = a;
                                    start.right = b.left;
                                    b.left = start;
                                    if (b.bal == 1)
                                        start.bal = -1;
                                    else
                                        start.bal = 0;
                                    if (b.bal == -1)
                                        a.bal = 1;
                                    else
                                        a.bal = 0;
                                    start = b;
                                }
                            }
                            start.bal = 0;
                            f = false;
                            // }
                        }
                    }
                }
                else if (String.Compare(F.login, start.feed[0].login) == 0)
                {
                    start.feed.Add(F);
                    f = false;
                }
            }
            head = start;
        }
        public void Del(ref t1 start, ref t1 a, ref bool f)
        {
            if (start.left != null)
            {
                Del(ref start.left, ref a, ref f);
                if (f == true)
                    BalR(ref start, ref f);
            }
            else
            {
                a.feed = start.feed;
                a = start;
                start = start.right;
                f = true;
            }
        }
        public void Delete(Feedback F,ref t1 start, ref bool f)
        {
            if (start == null)
            {
                Console.WriteLine("Дерево пустое");
                //return null;
            }
            else
            {
                if (String.Compare(F.login, start.feed[0].login) < 0)
                {
                    Delete(F, ref start.left, ref f);
                    if (f == true)
                        BalL(ref start, ref f);
                }
                else if (String.Compare(F.login, start.feed[0].login) > 0)
                {
                    Delete(F, ref start.right, ref f);
                    if (f == true)
                        BalR(ref start, ref f);
                }
                else if ((F.login == start.feed[0].login) && (start.feed.Count > 1))
                {
                    //f = false;
                    if (start.feed.Contains(F))
                    {
                        start.feed.Remove(F);
                        //start.feed[0] = start.feed[1];
                    }
                        
                }
                else
                {
                    t1 c = start;
                    if (c.right == null)
                    {
                        start = c.left;
                        f = true;
                    }
                    else if (c.left == null)
                    {
                        start = c.right;
                        f = true;
                    }
                    else
                    {
                        Del(ref c.right, ref c, ref f);
                        if (f == true)
                            BalL(ref start, ref f);
                    }
                }

            }
            head = start;
            //return start;
        }
        void BalR(ref t1 start, ref bool f)
        {
            if (start.bal == 1)
                start.bal = 0;
            else if (start.bal == 0)
            {
                start.bal = -1;
                f = false;
            }
            else
            {
                t1 a = start.left;
                if (a.bal <= 0)
                {
                    start.left = a.right;
                    a.right = start;
                    if (a.bal == 0)
                    {
                        start.bal = -1;
                        a.bal = 1;
                        f = false;
                    }
                    else
                    {
                        start.bal = 0;
                        a.bal = 0;
                    }
                    start = a;
                }
                else
                {
                    t1 b = a.right;
                    a.right = b.left;
                    b.left = a;
                    start.left = b.right;
                    b.right = start;
                    if (b.bal == -1)
                        start.bal = 1;
                    else
                        start.bal = 0;
                    if (b.bal == 1)
                        a.bal = -1;
                    else
                        a.bal = 0;
                    start = b;
                    b.bal = 0;
                }
            }
        }
        void BalL(ref t1 start, ref bool f)
        {
            if (start.bal == -1)
                start.bal = 0;
            else if (start.bal == 0)
            {
                start.bal = 1;
                f = false;
            }
            else
            {
                t1 a = start.right;
                if (a.bal >= 0)
                {
                    start.right = a.left;
                    a.left = start;
                    if (a.bal == 0)
                    {
                        start.bal = 1;
                        a.bal = -1;
                        f = false;
                    }
                    else
                    {
                        start.bal = 0;
                        a.bal = 0;
                    }
                    start = a;
                }
                else
                {
                    t1 b = a.left;
                    a.left = b.right;
                    b.right = a;
                    start.right = b.left;
                    b.left = start;
                    if (b.bal == 1)
                        start.bal = -1;
                    else
                        start.bal = 0;
                    if (b.bal == -1)
                        a.bal = 1;
                    else
                        a.bal = 0;
                    start = b;
                    b.bal = 0;
                    head = b;
                }
            }
        }
        public bool S(Feedback F, t1 start)
        {
            //if (start!=null)
            while ((start != null) && (F.login != start.feed[0].login))
            {
                if (String.Compare(F.login, start.feed[0].login) == -1)
                {
                    start = start.left;
                }
                else if (String.Compare(F.login, start.feed[0].login) == 1)
                    start = start.right;
            }
            if ((start != null) && (F.login == start.feed[0].login))
            {
                for (int i = 0; i < start.feed.Count; i++)
                {
                    if (F == start.feed[i])
                        return true;
                }
                return false;
            }
                //return true;
            else
                return false;
        }
        public void Search(string F, t1 start, ref List<Feedback> a)
        {
            while ((start != null) && (F != start.feed[0].login))
            {
                if (String.Compare(F, start.feed[0].login) == -1)
                    start = start.left;
                else if (String.Compare(F, start.feed[0].login) == 1)
                    start = start.right;
            }
            if ((start != null) && (F == start.feed[0].login))
                for (int i = 0; i < start.feed.Count; i++)
                {
                    a.Add(start.feed[i]);
                }
            else
                a = null;

        }
    //    public void Del_All(string l, ref t1 start, ref bool f)
    //    {
    //        if (start == null)
    //        {
    //            Console.WriteLine("Дерево пустое");
    //        }
    //        else
    //        {
    //            if (String.Compare(l, start.feed[0].login) < 0)
    //            {
    //                Del_All(l, ref start.left, ref f);
    //                if (f == true)
    //                    BalL(ref start, ref f);
    //            }
    //            else if (String.Compare(l, start.feed[0].login) > 0)
    //            {
    //                Del_All(l, ref start.right, ref f);
    //                if (f == true)
    //                    BalR(ref start, ref f);
    //            }
    //            else if (l == start.feed[0].login)
    //            {
    //                start.feed.Clear();
    //                t1 c = start;
    //                if (c.right == null)
    //                {
    //                    start = c.left;
    //                    f = true;
    //                }
    //                else if (c.left == null)
    //                {
    //                    start = c.right;
    //                    f = true;
    //                }
    //                else
    //                {
    //                    Del(ref c.right, ref c, ref f);
    //                    if (f == true)
    //                        BalL(ref start, ref f);
    //                }
    //            }

    //        }
    //        head = start;
    //    }
    }
}
