﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace final_project1
{
    /// <summary>
    /// Логика взаимодействия для Trees.xaml
    /// </summary>
    public partial class Trees : Window
    {
        public Trees(Tree_login tl)
        {
            InitializeComponent();
            Tree1.Text = "Дерево отзывов по логину";
            List<string> l = new List<string>();
            Show(tl.tree.head, 5, l);
            for (int j = 0; j < l.Count; j++)
            {
                Tree2.Text += l[j];
                Tree2.Text += "\n";
            }
        }
        public void Show(t1 start, int h, List<string> l)
        {
            if (start != null)
            {
                Show(start.right, h + 15, l);

                string p = "";
                for (int i = 1; i <= h; i++)
                    p += " ";

                l.Add(p + $"{start.feed[0].login} {start.feed[0].name} {start.feed[0].feed}  ({start.feed.Count})");

                Show(start.left, h + 15, l);
            }
        }
        public Trees(Tree_name tn)
        {
            InitializeComponent();
            Tree1.Text = "Дерево отзывов по названию";
            List<string> l = new List<string>();
            Show(tn.tree.head, 5, l);
            for (int j = 0; j < l.Count; j++)
            {
                Tree2.Text += l[j];
                Tree2.Text += "\n";
            }
        }
        public void Show(t2 start, int h, List<string> l)
        {
            if (start != null)
            {
                Show(start.right, h + 15, l);

                string p = "";
                for (int i = 1; i <= h; i++)
                    p += " ";

                l.Add(p + $"{start.feed[0].name} {start.feed[0].login} {start.feed[0].feed}  ({start.feed.Count})");

                Show(start.left, h + 15, l);
            }
        }
    }
}
