﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_project1
{
    public class Feedback
    {
        public string login { get; set; }
        public string name { get; set; }
        public string feed { get; set; }
        public Feedback()
        { }
        public Feedback(string l, string n, string f)
        {
            login = l;
            name = n;
            feed = f;
        }
        public void Show()
        {
            Console.WriteLine($"{login} {name} {feed}");
        }
        public static bool operator ==(Feedback a, Feedback b)
        {
            if (a.login == b.login && a.name == b.name && a.feed == b.feed)
                return true;
            else
                return false;
        }
        public static bool operator !=(Feedback a, Feedback b)
        {
            if (a.login == b.login && a.name == b.name && a.feed == b.feed)
                return false;
            else
                return true;
        }
    }
}
