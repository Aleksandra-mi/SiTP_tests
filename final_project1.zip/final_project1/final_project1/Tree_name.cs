﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_project1
{
    public class Tree_name
    {
        public t2 tree;
        public Tree_name()
        {
            tree = new t2();
        }
        public Tree_name(Feedback[] F)
        {
            bool f = true;
            tree = new t2();
            t2 a = tree.head;
            for (int i = 0; i < F.Length; i++)
            {
                tree.Add(F[i], ref a, ref f);
            }
            tree.head = a;
        }
    }
    public class t2
    {
        public List<Feedback> feed = new List<Feedback>();
        public t2 left;
        public t2 right;
        public t2 head = null;
        public int bal; // баланс -1(L>R) 0(L=R) 1(L<R)

        public t2()
        {
            bal = 0;
            left = null;
            right = null;
        }
        public void Add(Feedback F, ref t2 start, ref bool f)
        {
            if (start == null)
            {
                t2 t = new t2();
                t.feed.Add(F);
                start = t;
                f = true;
                //head = t;
            }
            else
            {
                if (String.Compare(F.name, start.feed[0].name) < 0) //левая строка меньше
                {
                    Add(F, ref start.left, ref f);
                    if (f == true)
                    {
                        if (start.bal == 1)
                        {
                            start.bal = 0;
                            f = false;
                        }
                        else if (start.bal == 0)
                        {
                            start.bal = -1;
                        }
                        else if (start.bal == -1)
                        {
                            t2 a = start.left;
                            //if (a != null)
                            //{
                            if (a.bal == -1)
                            {
                                start.left = a.right;
                                a.right = start;
                                start.bal = 0;
                                start = a;
                            }
                            else
                            {
                                t2 b = a.right;
                                if (b != null)
                                {
                                    a.right = b.left;
                                    b.left = a;
                                    start.left = b.right;
                                    b.right = start;
                                    if (b.bal == -1)
                                        start.bal = 1;
                                    else
                                        start.bal = 0;
                                    if (b.bal == 1)
                                        a.bal = -1;
                                    else
                                        a.bal = 0;
                                    start = b;
                                }

                            }
                            start.bal = 0;
                            f = false;
                            //}
                        }
                    }
                }
                else if (String.Compare(F.name, start.feed[0].name) > 0) //левая строка больше
                {
                    Add(F, ref start.right, ref f);
                    if (f == true)
                    {
                        if (start.bal == -1)
                        {
                            start.bal = 0;
                            f = false;
                        }
                        else if (start.bal == 0)
                        {
                            start.bal = 1;
                        }
                        else if (start.bal == 1)
                        {
                            t2 a = start.right;
                            //if (a != null)
                            //{
                            if (a.bal == 1)
                            {
                                start.right = a.left;
                                a.left = start;
                                start.bal = 0;
                                start = a;
                            }
                            else
                            {
                                t2 b = a.left;
                                if (b != null)
                                {
                                    a.left = b.right;
                                    b.right = a;
                                    start.right = b.left;
                                    b.left = start;
                                    if (b.bal == 1)
                                        start.bal = -1;
                                    else
                                        start.bal = 0;
                                    if (b.bal == -1)
                                        a.bal = 1;
                                    else
                                        a.bal = 0;
                                    start = b;
                                }
                            }
                            start.bal = 0;
                            f = false;
                            // }
                        }
                    }
                }
                else if (String.Compare(F.name, start.feed[0].name) == 0)
                {
                    start.feed.Add(F);
                    f = false;
                }
            }
            head = start;
        }
        public void Del(ref t2 start, ref t2 a, ref bool f)
        {
            if (start.left != null)
            {
                Del(ref start.left, ref a, ref f);
                if (f == true)
                    BalR(ref start, ref f);
            }
            else
            {
                a.feed = start.feed;
                a = start;
                start = start.right;
                f = true;
            }
        }
        public void Delete(Feedback F, ref t2 start, ref bool f)
        {
            if (start == null)
            {
                Console.WriteLine("Дерево пустое");
                //return null;
            }
            else
            {
                if (String.Compare(F.name, start.feed[0].name) < 0)
                {
                    Delete(F, ref start.left, ref f);
                    if (f == true)
                        BalL(ref start, ref f);
                }
                else if (String.Compare(F.name, start.feed[0].name) > 0)
                {
                    Delete(F, ref start.right, ref f);
                    if (f == true)
                        BalR(ref start, ref f);
                }
                else if ((F.name == start.feed[0].name) && (start.feed.Count > 1))
                {
                    //f = false;
                    if (start.feed.Contains(F))
                    {
                        start.feed.Remove(F);
                        //start.feed[0] = start.feed[1];
                    }

                }
                else
                {
                    t2 c = start;
                    if (c.right == null)
                    {
                        start = c.left;
                        f = true;
                    }
                    else if (c.left == null)
                    {
                        start = c.right;
                        f = true;
                    }
                    else
                    {
                        Del(ref c.right, ref c, ref f);
                        if (f == true)
                            BalL(ref start, ref f);
                    }
                }

            }
            head = start;
            //return start;
        }
        void BalR(ref t2 start, ref bool f)
        {
            if (start.bal == 1)
                start.bal = 0;
            else if (start.bal == 0)
            {
                start.bal = -1;
                f = false;
            }
            else
            {
                t2 a = start.left;
                if (a.bal <= 0)
                {
                    start.left = a.right;
                    a.right = start;
                    if (a.bal == 0)
                    {
                        start.bal = -1;
                        a.bal = 1;
                        f = false;
                    }
                    else
                    {
                        start.bal = 0;
                        a.bal = 0;
                    }
                    start = a;
                }
                else
                {
                    t2 b = a.right;
                    a.right = b.left;
                    b.left = a;
                    start.left = b.right;
                    b.right = start;
                    if (b.bal == -1)
                        start.bal = 1;
                    else
                        start.bal = 0;
                    if (b.bal == 1)
                        a.bal = -1;
                    else
                        a.bal = 0;
                    start = b;
                    b.bal = 0;
                }
            }
        }
        void BalL(ref t2 start, ref bool f)
        {
            if (start.bal == -1)
                start.bal = 0;
            else if (start.bal == 0)
            {
                start.bal = 1;
                f = false;
            }
            else
            {
                t2 a = start.right;
                if (a.bal >= 0)
                {
                    start.right = a.left;
                    a.left = start;
                    if (a.bal == 0)
                    {
                        start.bal = 1;
                        a.bal = -1;
                        f = false;
                    }
                    else
                    {
                        start.bal = 0;
                        a.bal = 0;
                    }
                    start = a;
                }
                else
                {
                    t2 b = a.left;
                    a.left = b.right;
                    b.right = a;
                    start.right = b.left;
                    b.left = start;
                    if (b.bal == 1)
                        start.bal = -1;
                    else
                        start.bal = 0;
                    if (b.bal == -1)
                        a.bal = 1;
                    else
                        a.bal = 0;
                    start = b;
                    b.bal = 0;
                    head = b;
                }
            }
        }
        public bool S(Feedback F, t2 start)
        {
            //if (start!=null)
            while ((start != null) && (F.name != start.feed[0].name))
            {
                if (String.Compare(F.name, start.feed[0].name) == -1)
                {
                    start = start.left;
                }
                else if (String.Compare(F.name, start.feed[0].name) == 1)
                    start = start.right;
            }
            if ((start != null) && (F.name == start.feed[0].name))
            {
                for (int i = 0; i < start.feed.Count; i++)
                {
                    if (F == start.feed[i])
                        return true;
                }
                return false;
            }
            //return true;
            else
                return false;
        }
        public void Search(string F, t2 start, ref List<Feedback> a)
        {
            while ((start != null) && (F != start.feed[0].name))
            {
                if (String.Compare(F, start.feed[0].name) == -1)
                    start = start.left;
                else if (String.Compare(F, start.feed[0].name) == 1)
                    start = start.right;
            }
            if ((start != null) && (F == start.feed[0].name))
                for (int i = 0; i < start.feed.Count; i++)
                {
                    a.Add(start.feed[i]);
                }
            else
                a = null;

        }
    }
}
