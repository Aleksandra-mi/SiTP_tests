﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_project1
{
    public class User
    {
        public string login { get; set; }
        public string data { get; set; }
        public double rate { get; set; }
        public User()
        { }
        public User(string l)
        {
            login = l;
            data = "11.11.1111";
            rate = 1.0;
        }
        public User(string l, string d, double r)
        {
            login = l;
            data = d;
            rate = r;
        }
        public void Show()
        {
            Console.WriteLine($"{login} {data} {rate}");
        }
        public static bool operator ==(User a, User b)
        {
            if (a.login == b.login && a.data == b.data && a.rate == b.rate)
                return true;
            else
                return false;
        }
        public static bool operator !=(User a, User b)
        {
            if (a.login == b.login && a.data == b.data && a.rate == b.rate)
                return false;
            else
                return true;
        }
        public string All()
        {
            return login + " " + data + " " + rate;
        }
        public int GetKey()
        {
            string s = login;
            int kk = 0;
            for (int i = 0; i < s.Length; i++)
            {
                kk += s[i];
            }
            return kk;
        }
    }
}
