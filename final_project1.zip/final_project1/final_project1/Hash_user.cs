﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_project1
{
    public class H
    {
        public User user { get; set; }
        public int ii { get; set; }
        public int status { get; set; }//статус
        public int h1 { get; set; }//первичный хеш
        public int h2 { get; set; }
        public H()
        {
            user = new User();
            ii = 0;
            status = 0;
            user.login = user.data = "";
            user.rate = 0.0;
            h1 = 0;
            h2 = 0;
        }
        public H(User u)
        {
            user = u;
            //h1 = HF1(u);
            h2 = 0;
            status = 1;
        }
        public H(User u, int k, int s)
        {
            user = u;
            h1 = 0;
            h2 = 0;
            status = s;
        }
        public void Show()
        {
            Console.WriteLine($"{status} {h1} {h2} {user}");
        }
    }
    public class Hash_user
    {
        public H[] hashtable { get; set; }
        public int n;
        public Hash_user(int s)
        {
            n = s;
            hashtable = new H[n];
            for (int j = 0; j < n; j++)
            {
                hashtable[j] = new H();
            }
            for (int k = 0; k < n; k++)
            {
                hashtable[k].ii = k;
            }
        }
        public Hash_user(User[] arr, int s)
        {
            if (!(arr.Length > s))
            {
                n = s;
                hashtable = new H[n];
                for (int j = 0; j < n; j++)
                {
                    hashtable[j] = new H();
                }
                for (int i = 0; i < arr.Length; i++)
                {
                    Add(arr[i]);
                }
                for (int k = 0; k < n; k++)
                {
                    hashtable[k].ii = k;
                }
            }

        }
        public int HF1(User u)
        {
            int a = u.GetKey();
            a = a % n;
            return a;
        }
        public int HF2(User u, int j)
        {
            int h = HF1(u);
            int a = (h + (j * 3)) % n;
            return a;
        }
        public int ACol(H a, int j)
        {
            //bool f = false;

            int hh;
            //int h1 = HF1(a.user);
            //int h2 = HF2(a.key);
            hh = HF2(a.user, j);
            if (hashtable[hh].status == 0 || hashtable[hh].status == 2)
                return hh;
            else if (hashtable[hh].status == 1 && hashtable[hh].user.login == a.user.login)
                return -1;
            else 
                return -2;
        }
        public void Add(User a)
        {
            bool f = false;
            int j = 0;
            int c;
            H aa = new H(a);
            int hh1 = HF1(a);
            while (j < n && f == false)
            {
                c = ACol(aa, j);
                
                if (c != -1 && c != -2)
                {
                    hashtable[c] = aa;
                    hashtable[c].ii = c;
                    hashtable[c].status = 1;
                    hashtable[c].h1 = hh1;
                    if (j > 0)
                        hashtable[c].h2 = c;
                    f = true;
                }
                else if (c == -1)
                {
                    Console.WriteLine("Запись с таким ключом уже есть в таблице");
                    f = true;
                }
                else if (c == -2)
                {
                    j++;
                }
            }
            if (j >= n)
                Console.WriteLine("Таблица заполнена");
        }
        public int DCol(H a, int j)
        {
            //bool f = false;
            int hh;
            //int h1 = HF1(a.user);
            //int h2 = HF2(a.key);
            //hh = (h1 + j * h2) % n;
            hh = HF2(a.user, j);

            if (hashtable[hh].status == 1 && hashtable[hh].user.login == a.user.login)
                return hh;
            else if (hashtable[hh].status == 0)
                return -1;
            else
                return -2;
        }
        public void Del(User a)
        {
            if(hashtable!=null)
            {
                bool f = false;
                int j = 0;
                int c;
                H aa = new H(a);
                while (j < n && f == false)
                {
                    c = DCol(aa, j);
                    if (c != -1 && c != -2)
                    {
                        hashtable[c].status = 2;
                        f = true;
                    }
                    else if (c == -1)
                    {
                        Console.WriteLine("Запись не найдена");
                        f = true;
                    }
                    else if (c == -2)
                    {
                        j++;
                    }
                }
                if (j >= n)
                    Console.WriteLine("Запись не найдена");
            }
            else
                Console.WriteLine("Таблица пустая");
        }
        public int FCol(H a, int j)
        {
            //bool f = false;
            int hh;
            //int h1 = HF1(a.user);
            //int h2 = HF2(a.key);
            //hh = (h1 + j * h2) % n;
            hh = HF2(a.user, j);

            if (hashtable[hh].status == 1 && hashtable[hh].user.login == a.user.login)
                return hh;
            else if (hashtable[hh].status == 0)
                return -1;
            else
                return -2;
        }
        public int Search(User a)
        {
            if (hashtable != null)
            {
                //bool f = false;
                //int j = 0;
                int c;
                H aa = new H(a);
                for (int j = 0; j < n; j++)
                {
                    c = FCol(aa, j);
                    if (c != -1 && c != -2)
                    {
                        Console.WriteLine("Запись найдена: ", hashtable[c].user);
                        //f = true;
                        return c;
                    }
                    else if (c == -1)
                    {
                        Console.WriteLine("Запись отсутствует");
                        //f = true;
                        return -1;
                    }
                }
                Console.WriteLine("Запись отсутствует");
                return -3;
            }
            else
            {
                Console.WriteLine("Таблица пустая");
                return -2;
            }
        }
        public List<Feedback> SS(List<Feedback> a, double r1, double r2)
        {
            List<Feedback> res = new List<Feedback>();
            for (int i = 0; i < a.Count; i++)
            {
                User u = new User(a[i].login);
                int s = Search(u);
                if ((s != -1) && (s != -2) && (s != -3))
                {
                    if ((hashtable[s].user.rate >= r1) && (hashtable[s].user.rate <= r2))
                        res.Add(a[i]);
                }
            }
            return res;
        }
    }
}
