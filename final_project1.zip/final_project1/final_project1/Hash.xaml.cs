﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace final_project1
{
    public partial class Hash : Window
    {
        public Hash(Hash_user HH)
        {
            InitializeComponent();
            List<string> ss = new List<string>();
            for (int i = 0; i < HH.n; i++)
            {
                ss.Add($" [{HH.hashtable[i].ii}]  {HH.hashtable[i].status}  h1={HH.hashtable[i].h1}  h2={HH.hashtable[i].h2}    {HH.hashtable[i].user.login}  {HH.hashtable[i].user.data}  {HH.hashtable[i].user.rate}  ");
            }
            for (int j = 0; j < ss.Count; j++)
            {
                Hash2.Text += ss[j];
                Hash2.Text += "\n";
            }
            //Hash2.Text.Split();
        }
    }
}
